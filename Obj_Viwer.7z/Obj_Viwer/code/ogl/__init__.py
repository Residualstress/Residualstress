# -*- coding:utf-8 -* 
#import platform
#import sys
#import re
#import numpy 
#import numpy as np
#import scipy.io as scio
#import cv2 as cv
#import cv2
#from PIL import Image
#from numpy import random
#import time
#import random
#import math
#import struct
#from skimage import exposure
#from numpy import random as nr
#from functools import reduce
#import time
#import ntpath
#import threading
#import PIL
#import shutil
#import subprocess
import pickle


import pygame, OpenGL
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
from OpenGL.GLUT.freeglut import *
